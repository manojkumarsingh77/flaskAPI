from flask import Flask
from flask import jsonify
from flask import request

app = Flask(__name__)

courses = [ {'name': 'Java',
             'Author':'Balaguruswamy',
             'course_id':'123',
              'Description':'Java is Platform Oriented'},
             {'name': 'python',
             'Author':'Guido Van Ransom',
              'course_id':'345',
              'Description':'Python is helping in buiding Frameworks'}
          ]

@app.route('/', methods=['GET'])
def hello_world():
    return jsonify({'message' : 'Hello, World!'})

@app.route('/courses', methods=['GET'])
def get():
    return jsonify({'courses' : courses})

@app.route('/courses/<int:course_id>', methods=['GET'])
def get_course(course_id):
    return jsonify({'courses' : courses[course_id]})

@app.route('/courses/', methods=['POST'])
def create():
    course={'name':'SQL',
             'Author':'Raghu rama krishna',
             'course_id':'234',
             'Description':'database system'}
    courses.append(course)
    return jsonify({'Created':course})

if __name__ == "__main__":
    app.run(debug=True)