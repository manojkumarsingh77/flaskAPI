from flask import Flask,jsonify
app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World! my first rest api'

@app.route('/amstrong/<int:n>')
def amstrong(n):
    order = len(str(n))
    sum = 0
    copy_n= n
    while n > 0:
        digit = n % 10
        sum += digit ** order
        n //= 10

    # display the result
    if sum == copy_n:
        print(f"{copy_n}is an Armstrong number")
       # return "True"
        result={
           "Number":n,
           "Amstrong":True
          }
    else:
        print(f"{copy_n}is an not Armstrong number")
       # return "False"
        result={
           "Number":n,
           "Amstrong":False
          }
    return jsonify(result)


if __name__=="__main__":
    app.run(debug=True)