''' Create a fastapi application to display
 the different food items from different country and apply some discount for each 
 food items based on item code'''
from fastapi import FastAPI
from enum import Enum
app=FastAPI()

class Availablecuisins(str,Enum):
    indian:'indian'
    italian:'italian'
    chinese:'chinese'
food_items={
         'indian':['Masala Dosa','Idly sambar'],
         'italian':['pizza','pasta'],
         'chinese':['noodles','gobimanchurian']
          }
valid_cuisines=food_items.keys()

@app.get("/get-items/{cuisine}")
async def get_items(cuisine:Availablecuisins):
    return food_items.get(cuisine)

coupon_code ={
    1:'10%',
    2:'20%',
    3:'30%'
}
@app.get('/get_coupons/{code}')
async def get_items(code:int):
    return   {'discount_amount':coupon_code }
        
